package br.com.judje;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
