export interface Usuario {
    id: number;
    email: string;
    nome: string;
}